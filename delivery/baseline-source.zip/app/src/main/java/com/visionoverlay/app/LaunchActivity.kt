package com.visionoverlay.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Local video and offline key gate; no network or storage permission is used. */
class LaunchActivity : ComponentActivity() {
    private lateinit var video: VideoView
    private lateinit var state: TextView
    private lateinit var enter: Button
    private var keyDialog: AlertDialog? = null
    private var authorized = false
    private var ready = false
    private var launching = false
    private var visible = false
    private var loading = false
    private var videoPaused = false
    private var playbackPosition = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRuntime.validated = false
        authorized = savedInstanceState?.getBoolean("authorized", false) ?: false
        val root = FrameLayout(this).apply { setBackgroundColor(AppUi.background) }
        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(24), d(16), d(24), d(16))
            background = AppUi.panel(this@LaunchActivity, 0xED13202F.toInt())
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(card) }
        root.addView(scroll, FrameLayout.LayoutParams(d(340), -1, Gravity.END).apply { setMargins(d(16), d(16), d(16), d(16)) })
        card.addView(AppUi.label(this, "白柠视觉辅助", 26f))
        card.addView(AppUi.label(this, "本地识别 · 人物与车辆", 14f, AppUi.accent).apply { setPadding(0, d(8), 0, d(12)) })
        state = AppUi.label(this, "正在准备模型，请输入卡密…", 14f, AppUi.muted)
        card.addView(state)
        card.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true }, LinearLayout.LayoutParams(-1, d(8)).apply { setMargins(0, d(12), 0, d(12)) })
        enter = AppUi.button(this, "输入卡密", true) { if (!authorized) showKeyDialog() else if (!ready) loadModels() else proceed() }
        card.addView(enter)
        card.addView(AppUi.button(this, "官方频道  ·  @BNSTR") { AppUi.openLink(this, AppUi.CHANNEL) }, row())
        card.addView(AppUi.button(this, "暂停视频") {
            videoPaused = !videoPaused
            if (videoPaused) video.pause() else video.start()
            (card.getChildAt(card.childCount - 2) as? Button)?.text = if (videoPaused) "播放视频" else "暂停视频"
        }, row())
        card.addView(AppUi.label(this, "telegram@BNSTR", 12f, AppUi.muted).apply { setPadding(0, d(12), 0, 0) })
        setContentView(root)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.launch_video}"))
        video.setOnPreparedListener { player ->
            player.isLooping = true; player.setVolume(0f, 0f)
            video.seekTo(playbackPosition)
            if (visible && !videoPaused) video.start()
        }
        video.setOnErrorListener { _, _, _ ->
            state.text = "视频播放暂不可用，卡密验证与加载仍可继续"; true
        }
        loadModels()
        if (!authorized) root.post { if (!isFinishing && !isDestroyed) showKeyDialog() }
    }

    private fun row() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(8) }
    private fun d(value: Int) = AppUi.dp(this, value)

    private fun loadModels() {
        if (loading) return
        loading = true
        lifecycleScope.launch {
            try {
                AppRuntime.prepare(assets, SettingsStore(this@LaunchActivity).read())
                ready = true
                state.text = if (authorized) "模型就绪，正在进入…" else "模型已就绪，等待卡密验证"
                proceed()
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) {
                state.text = "模型加载失败，点击重试"
                enter.text = if (authorized) "重试加载" else "输入卡密"
            } finally { loading = false }
        }
    }

    private fun showKeyDialog() {
        if (keyDialog?.isShowing == true) return
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(8), d(24), 0) }
        form.addView(AppUi.label(this, "卡密是：jujuenb\n输入后可进入相机；验证在本机完成。", 14f))
        val input = EditText(this).apply {
            hint = "请输入卡密"; isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setTextColor(AppUi.text); setHintTextColor(AppUi.muted)
            contentDescription = "卡密输入框，卡密为 jujuenb"
        }
        form.addView(input)
        val dialog = AlertDialog.Builder(this).setTitle("卡密验证").setView(form)
            .setPositiveButton("验证并进入", null)
            .setNeutralButton("官方频道", null)
            .setNegativeButton("退出") { _, _ -> finish() }
            .setCancelable(false).create()
        keyDialog = dialog
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { AppUi.openLink(this, AppUi.CHANNEL) }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (input.text.toString().trim() == "jujuenb") {
                    authorized = true; dialog.dismiss()
                    enter.text = if (ready) "进入相机" else "正在加载模型…"
                    state.text = if (ready) "卡密正确，正在进入…" else "卡密正确，模型仍在加载，请稍候…"
                    proceed()
                } else { input.error = "卡密不正确，请输入 jujuenb"; input.requestFocus() }
            }
        }
        dialog.show()
    }

    private fun proceed() {
        if (!authorized || !ready || !visible || launching) return
        launching = true; AppRuntime.validated = true
        startActivity(Intent(this, MainActivity::class.java)); finish()
    }
    override fun onResume() { super.onResume(); visible = true; if (::video.isInitialized && !videoPaused) video.start(); proceed() }
    override fun onPause() { visible = false; if (::video.isInitialized) { playbackPosition = video.currentPosition; video.pause() }; super.onPause() }
    override fun onSaveInstanceState(out: Bundle) { out.putBoolean("authorized", authorized); super.onSaveInstanceState(out) }
    override fun onDestroy() { keyDialog?.dismiss(); if (::video.isInitialized) video.stopPlayback(); super.onDestroy() }
}
