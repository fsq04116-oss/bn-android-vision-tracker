package com.visionoverlay.app

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Settings follow usage order. All edits are saved immediately. */
class SettingsActivity : ComponentActivity() {
    private lateinit var store: SettingsStore
    private var current = OverlaySettings()
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private val navigation = mutableListOf<Button>()
    private val names = listOf("操作控制", "识别性能", "绘制显示", "Root 增强", "关于与链接")
    private var selected = 0
    private var hasRoot = RootStatus.available()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this); current = store.read()
        selected = savedInstanceState?.getInt("category", 0) ?: 0
        buildUi(); showCategory(selected)
        lifecycleScope.launch {
            hasRoot = withContext(Dispatchers.IO) { RootStatus.refresh() }
            if (selected == 3) showCategory(3)
        }
    }
    private fun d(value: Int) = AppUi.dp(this, value)
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(AppUi.background); setPadding(d(16), d(16), d(16), d(24)) }
        val rail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, d(16), 0) }
        val railScroll = ScrollView(this).apply { addView(rail) }
        root.addView(railScroll, LinearLayout.LayoutParams(d(166), -1))
        rail.addView(AppUi.label(this, "白柠视觉辅助", 18f).apply { setPadding(0, 0, 0, d(8)) })
        rail.addView(AppUi.button(this, "返回相机") { finish() }, row())
        names.forEachIndexed { index, name ->
            val button = AppUi.button(this, name) { showCategory(index) }
            navigation.add(button); rail.addView(button, row())
        }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(8), d(8), d(24)) }
        scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(0, -1, 1f)); setContentView(root)
    }
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(8) }
    private fun save() = store.write(current)
    private fun note(text: String) { content.addView(AppUi.label(this, text, 13f, AppUi.muted).apply { setPadding(0, d(8), 0, d(16)) }) }
    private fun title(text: String) { content.addView(AppUi.label(this, text, 24f).apply { setPadding(0, 0, 0, d(8)) }) }
    private fun check(label: String, value: Boolean, change: (Boolean) -> Unit) {
        content.addView(Switch(this).apply {
            text = label; textSize = 15f; setTextColor(AppUi.text); isChecked = value
            minHeight = d(52); setPadding(d(16), d(8), d(16), d(8)); background = AppUi.panel(this@SettingsActivity)
            setOnCheckedChangeListener { _, enabled -> change(enabled); save() }
        }, row())
    }
    private fun choice(label: String, choices: Array<String>, position: Int, change: (Int) -> Unit) {
        content.addView(AppUi.label(this, label, 15f).apply { setPadding(0, d(16), 0, 0) })
        content.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, choices)
            setSelection(position.coerceIn(0, choices.lastIndex)); minimumHeight = d(48)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) { change(pos); save() }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }, row())
    }
    private fun showCategory(index: Int) {
        selected = index; content.removeAllViews(); scroll.scrollTo(0, 0)
        navigation.forEachIndexed { i, button ->
            button.isSelected = i == index
            button.setTextColor(if (i == index) AppUi.accent else AppUi.muted)
            button.contentDescription = names[i] + if (i == index) "，当前分类" else ""
        }
        title(names[index])
        when (index) {
            0 -> {
                note("音量加显示主页控制面板，音量减隐藏；识别会继续运行。")
                check("显示主页按钮与缩放条", current.controlsVisible) { current = current.copy(controlsVisible = it) }
                check("使用音量键显示 / 隐藏面板", current.volumeControls) { current = current.copy(volumeControls = it) }
                check("应用内悬浮操作按钮（无需 Root）", current.floatingControls) { current = current.copy(floatingControls = it) }
                note("悬浮按钮可拖动，点击展开或收起。只在应用内显示，无需系统悬浮窗权限；关闭音量键时保留触屏入口。")
            }
            1 -> {
                note("本地检测人物、自行车、汽车、摩托车、公共汽车和卡车。")
                val backends = arrayOf(BackendChoice.AUTO, BackendChoice.VULKAN, BackendChoice.CPU)
                choice("推理后端", arrayOf("自动", "Vulkan", "CPU（性能较低）"), backends.indexOf(current.backend).coerceAtLeast(0)) { current = current.copy(backend = backends[it]) }
                choice("模型模式", arrayOf("人物骨骼 + 人物 / 车辆检测", "快速检测（人物 / 车辆）"), if (current.modelMode == ModelMode.POSE) 0 else 1) { current = current.copy(modelMode = if (it == 0) ModelMode.POSE else ModelMode.DETECTION) }
                val sizes = arrayOf(320, 416, 640)
                choice("推理分辨率", arrayOf("320 · 更快", "416 · 均衡", "640 · 远处小目标"), sizes.indexOf(current.inputSize).coerceAtLeast(0)) { current = current.copy(inputSize = sizes[it]) }
                note("640 能保留更多小目标细节，推理耗时也会增加。严重失焦或遮挡仍会影响识别。")
                check("前置摄像头镜像", current.mirror) { current = current.copy(mirror = it) }
            }
            2 -> {
                note("绘制选项与显示信息。")
                check("人物检测框", current.personBox) { current = current.copy(personBox = it) }
                check("车辆检测框", current.vehicleBox) { current = current.copy(vehicleBox = it) }
                check("人物骨骼", current.skeleton) { current = current.copy(skeleton = it) }
                check("手持标记", current.heldMarker) { current = current.copy(heldMarker = it) }
                check("类别名称与置信度", current.labels) { current = current.copy(labels = it) }
                check("FPS 帧率", current.stats) { current = current.copy(stats = it) }
                check("标签黑色描边", current.labelStroke) { current = current.copy(labelStroke = it) }
            }
            3 -> renderRoot()
            4 -> {
                note("白柠视觉辅助  ${BuildConfig.VERSION_NAME}\n人物与车辆识别在本地完成，不上传相机画面。")
                content.addView(AppUi.button(this, "官方频道  ·  @BNSTR", true) { AppUi.openLink(this, AppUi.CHANNEL) }, row())
                content.addView(AppUi.button(this, "项目开源地址  ·  GitHub") { AppUi.openLink(this, AppUi.SOURCE) }, row())
                note("上游：nihui/ncnn-android-yolov8\n保留 ncnn / OpenCV 与原生相机示例的开源声明。\n作者：telegram@BNSTR")
                content.addView(AppUi.button(this, "查看上游项目") { AppUi.openLink(this, "https://github.com/nihui/ncnn-android-yolov8") }, row())
                content.addView(AppUi.button(this, "重置所有设置") {
                    AlertDialog.Builder(this).setTitle("恢复默认设置？").setMessage("绘制和操作偏好将恢复默认值。")
                        .setNegativeButton("取消", null).setPositiveButton("重置") { _, _ -> store.reset(); current = OverlaySettings(); showCategory(0) }.show()
                }, row())
            }
        }
    }
    private fun renderRoot() {
        note(if (hasRoot) "已检测到 Root。临时调整可能增加发热与功耗。" else "普通模式：Root 选项不可用；悬浮按钮与音量键仍可正常使用。")
        val controls = listOf("临时放宽 SELinux", "CPU 最低频率选项", "GPU 最低频率选项").map { label ->
            Switch(this).apply { text = label; textSize = 15f; setTextColor(AppUi.text); minHeight = d(52); isEnabled = hasRoot; alpha = if (hasRoot) 1f else .45f }.also { content.addView(it, row()) }
        }
        val apply = AppUi.button(this, "应用 Root 设置") { }
        apply.isEnabled = hasRoot
        apply.alpha = if (hasRoot) 1f else .45f
        apply.setOnClickListener {
            val selinux = controls[0].isChecked
            val cpu = controls[1].isChecked
            val gpu = controls[2].isChecked
            apply.isEnabled = false
            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) { RootStatus.applyThermalTuning(selinux, cpu, gpu) }
                apply.isEnabled = true
                Toast.makeText(this@SettingsActivity, if (result) "已应用" else "应用失败", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(apply, row())
    }
    override fun onSaveInstanceState(outState: Bundle) { outState.putInt("category", selected); super.onSaveInstanceState(outState) }
}
