package com.visionoverlay.app

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/** Shared visual tokens keep the loading, camera, and settings screens consistent. */
object AppUi {
    const val CHANNEL = "https://t.me/BNSTR"
    const val SOURCE = "https://github.com/fsq04116-oss/bn-android-vision-tracker"
    val background = Color.rgb(8, 15, 24)
    val surface = Color.rgb(19, 32, 47)
    val text = Color.rgb(235, 243, 252)
    val muted = Color.rgb(163, 184, 205)
    val accent = Color.rgb(125, 224, 207)

    fun dp(context: Context, value: Int) = (value * context.resources.displayMetrics.density).toInt()
    fun panel(context: Context, color: Int = surface, radius: Int = 16) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(context, radius).toFloat()
        setStroke(dp(context, 1), Color.argb(60, 143, 179, 203))
    }
    fun label(context: Context, value: String, size: Float = 14f, color: Int = text) = TextView(context).apply {
        text = value; textSize = size; setTextColor(color)
    }
    fun button(context: Context, value: String, primary: Boolean = false, action: () -> Unit) = Button(context).apply {
        text = value; textSize = 14f; isAllCaps = false
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) AppUi.background else AppUi.text)
        background = RippleDrawable(ColorStateList.valueOf(0x339FFFFF), panel(context, if (primary) accent else surface, 12), null)
        minHeight = dp(context, 48); minimumHeight = dp(context, 48)
        setPadding(dp(context, 16), 0, dp(context, 16), 0)
        setOnClickListener { action() }
    }
    fun openLink(context: Context, url: String) {
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: android.content.ActivityNotFoundException) {
            Toast.makeText(context, "请安装浏览器或 Telegram 后打开", Toast.LENGTH_LONG).show()
        }
    }
}
